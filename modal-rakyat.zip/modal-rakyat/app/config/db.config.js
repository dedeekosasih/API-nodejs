module.exports = {
    HOST: "localhost",
    USER: "root",
    PASSWORD: "",
    DB: "modal_rakyat"
  };